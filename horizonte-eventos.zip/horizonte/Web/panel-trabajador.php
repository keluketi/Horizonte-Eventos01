<?php
declare(strict_types=1);

require_once __DIR__ . '/app/bootstrap.php';
(new \Horizonte\Controllers\EmployeeController())->dashboard();
