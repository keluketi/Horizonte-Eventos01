package com.horizonteeventos.app;

import com.horizonteeventos.dao.ClienteDAO;
import com.horizonteeventos.dao.CatalogoEventoDAO;
import com.horizonteeventos.dao.ConsultaModuloDAO;
import com.horizonteeventos.dao.EventoDetalleDAO;
import com.horizonteeventos.dao.impl.ClienteDAOImpl;
import com.horizonteeventos.dao.impl.CatalogoEventoDAOImpl;
import com.horizonteeventos.dao.impl.ConsultaModuloDAOImpl;
import com.horizonteeventos.dao.impl.EventoDetalleDAOImpl;
import com.horizonteeventos.modelo.Cliente;
import com.horizonteeventos.modelo.DetalleEvento;
import com.horizonteeventos.modelo.DatosTabla;
import com.horizonteeventos.modelo.Empleado;
import com.horizonteeventos.modelo.Paquete;
import com.horizonteeventos.modelo.Servicio;
import com.horizonteeventos.modelo.ServicioEventoDetalle;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import java.time.format.DateTimeFormatter;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/** Dashboard de Administración con la paleta de colores institucional unificada. */
public class AdministracionFrame extends JFrame {

    // =========================================================
    // COLORES INSTITUCIONALES UNIFICADOS
    // =========================================================
    private final Color AZUL_PRINCIPAL = new Color(18, 51, 81);
    private final Color AZUL_SECUNDARIO = new Color(28, 61, 88);
    private final Color NARANJA = new Color(150, 59, 12);
    private final Color NARANJA_HOVER = new Color(119, 43, 6);
    private final Color GRIS_FONDO = new Color(245, 246, 249);
    private static final String INICIO = "Dashboard";

    private final Empleado usuario;
    private final ClienteDAO clienteDAO = new ClienteDAOImpl();
    private final CatalogoEventoDAO catalogoEventoDAO = new CatalogoEventoDAOImpl();
    private final ConsultaModuloDAO consultaDAO = new ConsultaModuloDAOImpl();
    private final EventoDetalleDAO eventoDetalleDAO = new EventoDetalleDAOImpl();
    private final CardLayout tarjetas = new CardLayout();
    private final JPanel contenido = new JPanel(tarjetas);
    
    private final DefaultTableModel modeloClientes = new DefaultTableModel(
            new Object[] {"ID", "Nombre", "Apellido", "DNI/CUIT", "Email", "Teléfono"}, 0) {
        private static final long serialVersionUID = 1L;
        @Override public boolean isCellEditable(int fila, int columna) { return false; }
    };
    private final JTable tablaClientes = new JTable(modeloClientes);
    private final DefaultTableModel modeloPaquetes = new DefaultTableModel(
            new Object[] {"ID", "Paquete", "Descripción", "Precio base"}, 0) {
        private static final long serialVersionUID = 1L;
        @Override public boolean isCellEditable(int fila, int columna) { return false; }
    };
    private final JTable tablaPaquetes = new JTable(modeloPaquetes);
    private final JTextArea detalleEventoTexto = new JTextArea();

    public AdministracionFrame(Empleado empleado) {
        super("Horizonte Eventos - Panel de Administración");
        AccesibilidadUI.aplicar();
        this.usuario = empleado;
        RegistroAccionesUI.iniciar();
        RegistroAccionesUI.establecerUsuario(empleado);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1050, 650));
        setSize(1200, 700);
        setLocationRelativeTo(null);
        
        JPanel panelPrincipal = new JPanel(new BorderLayout(12, 12));
        panelPrincipal.setBackground(GRIS_FONDO);
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        setContentPane(panelPrincipal);

        panelPrincipal.add(crearEncabezado(), BorderLayout.NORTH);
        panelPrincipal.add(crearNavegacion(), BorderLayout.WEST);
        
        contenido.setOpaque(false);
        panelPrincipal.add(contenido, BorderLayout.CENTER);

        contenido.add(crearInicio(), INICIO);
        contenido.add(crearPanelClientes(), "Clientes");
        contenido.add(crearPanelPaquetes(), "Paquetes");
        agregarPanelConsulta("Presupuestos");
        agregarPanelConsulta("Eventos");
        agregarPanelConsulta("Pagos");
        agregarPanelConsulta("Comprobantes");
        agregarPanelConsulta("Proveedores");
        agregarPanelConsulta("Servicios");
        agregarPanelConsulta("Espacios");
        agregarPanelConsulta("Reportes");

        configurarTabla(tablaClientes);
        configurarTabla(tablaPaquetes);
        tarjetas.show(contenido, INICIO);
        cargarClientes();
        cargarPaquetes();
    }

    private JPanel crearEncabezado() {
        JPanel encabezado = new JPanel(new BorderLayout(16, 0));
        encabezado.setBackground(Color.WHITE);
        encabezado.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        JPanel marca = new JPanel();
        marca.setOpaque(false);
        marca.setLayout(new BoxLayout(marca, BoxLayout.Y_AXIS));
        JLabel nombreEmpresa = new JLabel("HORIZONTE EVENTOS");
        nombreEmpresa.setFont(new Font("Verdana", Font.BOLD, 18));
        nombreEmpresa.setForeground(AZUL_PRINCIPAL);
        JLabel subtitulo = new JLabel("Sistema de Gestión · Panel de Administración");
        subtitulo.setFont(new Font("Verdana", Font.PLAIN, 12));
        subtitulo.setForeground(new Color(105, 117, 130));
        marca.add(nombreEmpresa);
        marca.add(Box.createVerticalStrut(3));
        marca.add(subtitulo);
        encabezado.add(marca, BorderLayout.WEST);

        JPanel sesion = new JPanel(new BorderLayout(12, 0));
        sesion.setOpaque(false);
        JLabel usuarioLabel = new JLabel("Administrador/a: " + usuario.getNombre() + " " + usuario.getApellido());
        usuarioLabel.setFont(new Font("Verdana", Font.BOLD, 13));
        usuarioLabel.setForeground(AZUL_SECUNDARIO);
        sesion.add(usuarioLabel, BorderLayout.CENTER);

        JButton cerrarSesion = crearBotonEstilizado("Cerrar Sesión", new Color(180, 50, 50));
        cerrarSesion.addActionListener(e -> cerrarSesion());
        sesion.add(cerrarSesion, BorderLayout.EAST);
        
        encabezado.add(sesion, BorderLayout.EAST);
        return encabezado;
    }

    private JPanel crearNavegacion() {
        JPanel navegacion = new JPanel();
        navegacion.setLayout(new BoxLayout(navegacion, BoxLayout.Y_AXIS));
        navegacion.setBackground(AZUL_PRINCIPAL);
        navegacion.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
        navegacion.setPreferredSize(new Dimension(210, 0));

        JLabel titulo = new JLabel("  MENÚ ADMINISTRATIVO");
        titulo.setForeground(new Color(180, 198, 215));
        titulo.setFont(new Font("Verdana", Font.BOLD, 11));
        titulo.setAlignmentX(LEFT_ALIGNMENT);
        navegacion.add(titulo);
        navegacion.add(Box.createVerticalStrut(12));

        agregarBotonNav(navegacion, "Dashboard", INICIO);
        agregarBotonNav(navegacion, "Clientes", "Clientes");
        agregarBotonNav(navegacion, "Presupuestos", "Presupuestos");
        agregarBotonNav(navegacion, "Paquetes", "Paquetes");
        agregarBotonNav(navegacion, "Eventos", "Eventos");
        agregarBotonNav(navegacion, "Pagos", "Pagos");
        agregarBotonNav(navegacion, "Comprobantes", "Comprobantes");
        agregarBotonNav(navegacion, "Proveedores", "Proveedores");
        agregarBotonNav(navegacion, "Servicios", "Servicios");
        agregarBotonNav(navegacion, "Espacios", "Espacios");
        agregarBotonNav(navegacion, "Reportes", "Reportes");
        
        navegacion.add(Box.createVerticalGlue());
        return navegacion;
    }

    private void agregarBotonNav(JPanel navegacion, String texto, String tarjeta) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Verdana", Font.BOLD, 12));
        boton.setForeground(Color.WHITE);
        boton.setBackground(AZUL_PRINCIPAL);
        boton.setFocusPainted(false);
        boton.setHorizontalAlignment(JButton.LEFT);
        boton.setAlignmentX(LEFT_ALIGNMENT);
        boton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        boton.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 10));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(AZUL_SECUNDARIO);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(AZUL_PRINCIPAL);
            }
        });

        boton.addActionListener(e -> tarjetas.show(contenido, tarjeta));
        navegacion.add(boton);
        navegacion.add(Box.createVerticalStrut(2));
    }

    private JPanel crearInicio() {
        JPanel inicio = new JPanel(new BorderLayout(0, 20));
        inicio.setOpaque(false);
        inicio.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel titulos = new JPanel();
        titulos.setOpaque(false);
        titulos.setLayout(new BoxLayout(titulos, BoxLayout.Y_AXIS));
        JLabel titulo = new JLabel("Dashboard General");
        titulo.setFont(new Font("Verdana", Font.BOLD, 24));
        titulo.setForeground(AZUL_PRINCIPAL);
        JLabel descripcion = new JLabel("Resumen operativo del sistema Horizonte Eventos");
        descripcion.setFont(new Font("Verdana", Font.PLAIN, 13));
        descripcion.setForeground(new Color(105, 117, 130));
        titulos.add(titulo);
        titulos.add(Box.createVerticalStrut(4));
        titulos.add(descripcion);
        inicio.add(titulos, BorderLayout.NORTH);

        JPanel tarjetasResumen = new JPanel(new GridLayout(1, 2, 15, 15));
        tarjetasResumen.setOpaque(false);
        
        DatosTabla reporte = null;
        try { reporte = consultaDAO.consultar("Reportes"); } catch (SQLException ignored) { }
        
        tarjetasResumen.add(crearTarjetaKPI("Eventos registrados", valorReporte(reporte, "Eventos registrados"), AZUL_SECUNDARIO));
        tarjetasResumen.add(crearTarjetaKPI("Presupuestos aceptados", valorReporte(reporte, "Presupuestos aceptados"), AZUL_PRINCIPAL));

        JPanel cuerpo = new JPanel(new BorderLayout(0, 15));
        cuerpo.setOpaque(false);
        cuerpo.add(tarjetasResumen, BorderLayout.NORTH);
        
        JPanel bienvenida = new JPanel(new BorderLayout());
        bienvenida.setBackground(Color.WHITE);
        bienvenida.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(228, 233, 239)),
                BorderFactory.createEmptyBorder(20, 22, 20, 22)));
        JLabel mensaje = new JLabel("<html><b>Bienvenido/a, " + usuario.getNombre() + ".</b><br><br>Utiliza el menú lateral izquierdo para navegar y administrar los diferentes módulos operativos y comerciales de la empresa.</html>");
        mensaje.setFont(new Font("Verdana", Font.PLAIN, 14));
        bienvenida.add(mensaje, BorderLayout.CENTER);
        
        cuerpo.add(bienvenida, BorderLayout.CENTER);
        inicio.add(cuerpo, BorderLayout.CENTER);
        return inicio;
    }

    private JPanel crearTarjetaKPI(String titulo, String valor, Color colorBorde) {
        JPanel tarjeta = new JPanel(new BorderLayout());
        tarjeta.setBackground(Color.WHITE);
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colorBorde, 2),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JLabel lblTitulo = new JLabel(titulo, JLabel.CENTER);
        lblTitulo.setFont(new Font("Verdana", Font.BOLD, 13));
        lblTitulo.setForeground(colorBorde);

        JLabel lblValor = new JLabel(valor, JLabel.CENTER);
        lblValor.setFont(new Font("Verdana", Font.BOLD, 22));
        lblValor.setForeground(AZUL_PRINCIPAL);

        tarjeta.add(lblTitulo, BorderLayout.NORTH);
        tarjeta.add(Box.createVerticalStrut(10), BorderLayout.CENTER);
        tarjeta.add(lblValor, BorderLayout.SOUTH);

        return tarjeta;
    }

    private String valorReporte(DatosTabla datos, String indicador) {
        if (datos == null) return "—";
        for (Object[] fila : datos.getFilas()) {
            if (indicador.equals(String.valueOf(fila[0]))) return String.valueOf(fila[1]);
        }
        return "0";
    }

    private JPanel crearPanelPaquetes() {
        JPanel panel = crearPanelBase("Paquetes", "Modifica las plantillas y sus recursos incluidos");
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        acciones.setOpaque(false);
        JButton nuevo = crearBotonEstilizado("Crear paquete", NARANJA);
        JButton editar = crearBotonEstilizado("Editar seleccionado", AZUL_SECUNDARIO);
        JButton actualizar = crearBotonEstilizado("Actualizar lista", AZUL_PRINCIPAL);
        acciones.add(nuevo);
        acciones.add(editar);
        acciones.add(actualizar);
        panel.add(new JScrollPane(tablaPaquetes), BorderLayout.CENTER);
        panel.add(acciones, BorderLayout.SOUTH);
        nuevo.addActionListener(e -> abrirEditorPaquete(new Paquete(0, "", "", BigDecimal.ZERO)));
        editar.addActionListener(e -> editarPaqueteSeleccionado());
        actualizar.addActionListener(e -> cargarPaquetes());
        return panel;
    }

    private void editarPaqueteSeleccionado() {
        int filaVista = tablaPaquetes.getSelectedRow();
        if (filaVista < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un paquete para modificarlo.");
            return;
        }
        int fila = tablaPaquetes.convertRowIndexToModel(filaVista);
        Object descripcion = modeloPaquetes.getValueAt(fila, 2);
        Paquete paquete = new Paquete((Integer) modeloPaquetes.getValueAt(fila, 0),
                String.valueOf(modeloPaquetes.getValueAt(fila, 1)),
                descripcion == null ? "" : String.valueOf(descripcion),
                (BigDecimal) modeloPaquetes.getValueAt(fila, 3));
        abrirEditorPaquete(paquete);
    }

    private void abrirEditorPaquete(Paquete paquete) {
        EditarPaqueteDialog dialogo = new EditarPaqueteDialog(this, catalogoEventoDAO, paquete);
        dialogo.setVisible(true);
        if (dialogo.isGuardado()) cargarPaquetes();
    }

    private void cargarPaquetes() {
        try {
            modeloPaquetes.setRowCount(0);
            for (Paquete paquete : catalogoEventoDAO.listarPaquetes()) {
                modeloPaquetes.addRow(new Object[] {paquete.getId(), paquete.getNombre(),
                        paquete.getDescripcion(), paquete.getPrecioFijo()});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudieron cargar los paquetes: " + ex.getMessage(),
                    "Error de paquetes", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JPanel crearPanelClientes() {
        JPanel panel = crearPanelBase("Gestión de Clientes", "Registro y mantenimiento de clientes en el sistema");
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        acciones.setOpaque(false);
        
        JButton nuevo = crearBotonEstilizado("Nuevo cliente", NARANJA);
        JButton editar = crearBotonEstilizado("Editar seleccionado", AZUL_SECUNDARIO);
        JButton eliminar = crearBotonEstilizado("Eliminar seleccionado", new Color(180, 50, 50));
        JButton actualizar = crearBotonEstilizado("Actualizar lista", AZUL_PRINCIPAL);
        
        acciones.add(nuevo); 
        acciones.add(editar); 
        acciones.add(eliminar); 
        acciones.add(actualizar);
        
        JScrollPane scroll = new JScrollPane(tablaClientes);
        scroll.getViewport().setBackground(Color.WHITE);
        JPanel lista = new JPanel(new BorderLayout(0, 8));
        lista.setOpaque(false);
        lista.add(PanelRolUI.crearBarraFiltroOrden(tablaClientes), BorderLayout.NORTH);
        lista.add(scroll, BorderLayout.CENTER);

        panel.add(lista, BorderLayout.CENTER);
        panel.add(acciones, BorderLayout.SOUTH);
        
        nuevo.addActionListener(e -> nuevoCliente());
        editar.addActionListener(e -> editarCliente());
        eliminar.addActionListener(e -> eliminarCliente());
        actualizar.addActionListener(e -> cargarClientes());
        return panel;
    }

    private JPanel crearPanelBase(String titulo, String subtitulo) {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JPanel encabezado = new JPanel();
        encabezado.setOpaque(false);
        encabezado.setLayout(new BoxLayout(encabezado, BoxLayout.Y_AXIS));
        
        JLabel nombre = new JLabel(titulo);
        nombre.setFont(new Font("Verdana", Font.BOLD, 22));
        nombre.setForeground(AZUL_PRINCIPAL);
        
        JLabel descripcion = new JLabel(subtitulo);
        descripcion.setFont(new Font("Verdana", Font.PLAIN, 13));
        descripcion.setForeground(new Color(105, 117, 130));
        
        encabezado.add(nombre);
        encabezado.add(Box.createVerticalStrut(3));
        encabezado.add(descripcion);
        panel.add(encabezado, BorderLayout.NORTH);
        return panel;
    }

    private void agregarPanelConsulta(String nombreModulo) {
        JPanel panel = crearPanelBase(nombreModulo, "Consulta general de información registrada en base de datos");
        DefaultTableModel modelo = new DefaultTableModel() {
            private static final long serialVersionUID = 1L;
            @Override public boolean isCellEditable(int fila, int columna) { return false; }
        };
        JTable tabla = new JTable(modelo);
        configurarTabla(tabla);
        
        JButton actualizar = crearBotonEstilizado("Actualizar información", AZUL_SECUNDARIO);
        JPanel pie = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 10));
        pie.setOpaque(false);
        pie.add(actualizar);
        if ("Eventos".equals(nombreModulo)) {
            JButton crearEvento = crearBotonEstilizado("Crear evento", NARANJA);
            pie.add(crearEvento);
            crearEvento.addActionListener(e -> {
                try {
                    CrearEventoDialog dialogo = new CrearEventoDialog(this);
                    dialogo.setVisible(true);
                    int nuevoId = dialogo.getIdEventoCreado();
                    cargarModulo(nombreModulo, modelo);
                    if (nuevoId > 0) seleccionarEvento(tabla, modelo, nuevoId);
                } catch (RuntimeException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this,
                            "No se pudo abrir el formulario de creación de eventos:\n" + ex.getMessage(),
                            "Error al abrir el formulario", JOptionPane.ERROR_MESSAGE);
                }
            });
        }
        if ("Servicios".equals(nombreModulo)) {
            JButton nuevoServicio = crearBotonEstilizado("Agregar recurso / servicio", NARANJA);
            JButton editarServicio = crearBotonEstilizado("Editar seleccionado", AZUL_SECUNDARIO);
            JButton eliminarServicio = crearBotonEstilizado("Quitar del catálogo", new Color(180, 50, 50));
            pie.add(nuevoServicio);
            pie.add(editarServicio);
            pie.add(eliminarServicio);
            nuevoServicio.addActionListener(e -> editarServicio(modelo, null));
            editarServicio.addActionListener(e -> {
                int filaVista = tabla.getSelectedRow();
                if (filaVista < 0) {
                    JOptionPane.showMessageDialog(this, "Selecciona un servicio para modificar.");
                    return;
                }
                int fila = tabla.convertRowIndexToModel(filaVista);
                Servicio servicio = new Servicio((Integer) modelo.getValueAt(fila, 0),
                        String.valueOf(modelo.getValueAt(fila, 1)),
                        new BigDecimal(String.valueOf(modelo.getValueAt(fila, 3))),
                        leerCapacidad(modelo.getValueAt(fila, 4)));
                editarServicio(modelo, servicio);
            });
            eliminarServicio.addActionListener(e -> eliminarServicioSeleccionado(tabla, modelo));
        }
        
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.getViewport().setBackground(Color.WHITE);
        
        if ("Eventos".equals(nombreModulo)) {
            configurarPanelDetalleEvento();
            JPanel detalle = new JPanel(new BorderLayout(0, 6));
            detalle.setBackground(Color.WHITE);
            detalle.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(228, 233, 239)),
                    BorderFactory.createEmptyBorder(8, 10, 8, 10)));
            JLabel tituloDetalle = new JLabel("Detalle del evento seleccionado");
            tituloDetalle.setFont(new Font("Verdana", Font.BOLD, 14));
            tituloDetalle.setForeground(AZUL_PRINCIPAL);
            detalle.add(tituloDetalle, BorderLayout.NORTH);
            detalle.add(new JScrollPane(detalleEventoTexto), BorderLayout.CENTER);

            JSplitPane panelEventos = new JSplitPane(JSplitPane.VERTICAL_SPLIT, scroll, detalle);
            panelEventos.setResizeWeight(0.58);
            panelEventos.setDividerLocation(285);
            panelEventos.setBorder(null);
            panel.add(panelEventos, BorderLayout.CENTER);
            tabla.getSelectionModel().addListSelectionListener(e -> {
                if (e.getValueIsAdjusting()) return;
                int filaVista = tabla.getSelectedRow();
                if (filaVista < 0) {
                    detalleEventoTexto.setText("Selecciona un evento de la lista para ver su ficha detallada.");
                    return;
                }
                int fila = tabla.convertRowIndexToModel(filaVista);
                Object id = modelo.getValueAt(fila, 0);
                if (id instanceof Number) mostrarDetalleEvento(((Number) id).intValue());
            });
            tabla.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                    int filaVista = tabla.rowAtPoint(e.getPoint());
                    if (filaVista < 0) return;
                    tabla.setRowSelectionInterval(filaVista, filaVista);
                    int filaModelo = tabla.convertRowIndexToModel(filaVista);
                    Object id = modelo.getValueAt(filaModelo, 0);
                    if (id instanceof Number) {
                        new SimulacionFacturacionDialog(AdministracionFrame.this,
                                ((Number) id).intValue()).setVisible(true);
                    }
                }
            });
        } else {
            panel.add(scroll, BorderLayout.CENTER);
        }
        panel.add(pie, BorderLayout.SOUTH);
        
        actualizar.addActionListener(e -> cargarModulo(nombreModulo, modelo));
        contenido.add(panel, nombreModulo);
        cargarModulo(nombreModulo, modelo);
    }

    private void configurarPanelDetalleEvento() {
        detalleEventoTexto.setEditable(false);
        detalleEventoTexto.setLineWrap(true);
        detalleEventoTexto.setWrapStyleWord(true);
        detalleEventoTexto.setFont(new Font("Verdana", Font.PLAIN, 12));
        detalleEventoTexto.setForeground(AZUL_PRINCIPAL);
        detalleEventoTexto.setBackground(Color.WHITE);
        detalleEventoTexto.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        detalleEventoTexto.setText("Selecciona un evento de la lista para ver su ficha detallada.");
    }

    private void seleccionarEvento(JTable tabla, DefaultTableModel modelo, int idEvento) {
        for (int fila = 0; fila < modelo.getRowCount(); fila++) {
            Object valor = modelo.getValueAt(fila, 0);
            if (valor instanceof Number && ((Number) valor).intValue() == idEvento) {
                int filaVista = tabla.convertRowIndexToView(fila);
                if (filaVista >= 0) tabla.setRowSelectionInterval(filaVista, filaVista);
                return;
            }
        }
    }

    private void mostrarDetalleEvento(int idEvento) {
        try {
            java.util.Optional<DetalleEvento> resultado = eventoDetalleDAO.buscarPorId(idEvento);
            if (!resultado.isPresent()) {
                detalleEventoTexto.setText("No se encontró el evento seleccionado.");
                return;
            }
            DetalleEvento detalle = resultado.get();
            DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("HH:mm");
            StringBuilder texto = new StringBuilder();
            texto.append("EVENTO #").append(detalle.getId()).append("\n")
                    .append("Tipo: ").append(valorOAlternativa(detalle.getTipo(), "Sin tipo")).append("\n")
                    .append("Estado: ").append(valorOAlternativa(detalle.getEstado(), "Sin estado")).append("\n")
                    .append("Fecha: ").append(detalle.getFecha()).append("   Horario: ")
                    .append(detalle.getHoraInicio().format(formatoHora)).append(" a ")
                    .append(detalle.getHoraFin().format(formatoHora)).append("\n")
                    .append("Salón: ").append(valorOAlternativa(detalle.getEspacio(), "Sin salón"))
                    .append("\n\nCLIENTE\n")
                    .append(valorOAlternativa(detalle.getCliente(), "Sin cliente"))
                    .append(" · DNI/CUIT: ").append(valorOAlternativa(detalle.getDocumentoCliente(), "Sin informar"))
                    .append(" · Email: ").append(valorOAlternativa(detalle.getEmailCliente(), "Sin informar"))
                    .append(" · Teléfono: ").append(valorOAlternativa(detalle.getTelefonoCliente(), "Sin informar"))
                    .append("\n\nINVITADOS\nPresupuestados: ").append(detalle.getInvitados())
                    .append(" · Asistencia real: ").append(detalle.getAsistenciaReal() == null
                            ? "Pendiente" : detalle.getAsistenciaReal())
                    .append("\n\nPAQUETE\n");
            if (detalle.getPaquete() == null) {
                texto.append("Personalizado sin plantilla de paquete");
            } else {
                texto.append(detalle.getPaquete());
                if (detalle.getPrecioPaquete() != null) {
                    texto.append(" · Precio base: ").append(formatearDinero(detalle.getPrecioPaquete()));
                }
                if (detalle.getDescripcionPaquete() != null && !detalle.getDescripcionPaquete().trim().isEmpty()) {
                    texto.append("\n").append(detalle.getDescripcionPaquete());
                }
            }
            texto.append("\n\nSERVICIOS CONTRATADOS\n");
            if (detalle.getServicios().isEmpty()) {
                texto.append("No se registraron servicios para este evento.");
            } else {
                for (ServicioEventoDetalle servicio : detalle.getServicios()) {
                    texto.append("- ").append(servicio.getNombre()).append(" · Cantidad: ")
                            .append(servicio.getCantidad()).append(" · Precio acordado: ")
                            .append(formatearDinero(servicio.getPrecioAcordado()))
                            .append(" · Proveedor: ").append(valorOAlternativa(servicio.getProveedor(), "Sin informar"))
                            .append("\n");
                }
            }
            texto.append("\nREQUERIMIENTOS / OBSERVACIONES\n")
                    .append(valorOAlternativa(detalle.getObservaciones(), "Sin observaciones"));
            detalleEventoTexto.setText(texto.toString());
            detalleEventoTexto.setCaretPosition(0);
        } catch (SQLException ex) {
            detalleEventoTexto.setText("No se pudo cargar el detalle del evento: " + ex.getMessage());
        }
    }

    private String valorOAlternativa(String valor, String alternativa) {
        return valor == null || valor.trim().isEmpty() ? alternativa : valor;
    }

    private String formatearDinero(BigDecimal monto) {
        if (monto == null) return "No informado";
        return NumberFormat.getCurrencyInstance(new Locale("es", "AR")).format(monto);
    }

    private void editarServicio(DefaultTableModel modelo, Servicio original) {
        JTextField nombre = new JTextField(original == null ? "" : original.getNombre(), 22);
        JTextField costo = new JTextField(original == null ? "0.00" : original.getCostoUnitario().toPlainString(), 12);
        JTextField capacidad = new JTextField(original == null || original.getCantidadDisponible() == null
                ? "" : String.valueOf(original.getCantidadDisponible()), 12);
        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 8));
        formulario.add(new JLabel("Nombre del recurso o servicio:"));
        formulario.add(nombre);
        formulario.add(new JLabel("Costo unitario de referencia:"));
        formulario.add(costo);
        formulario.add(new JLabel("Cantidad disponible (vacío = confirmar manualmente):"));
        formulario.add(capacidad);
        int opcion = JOptionPane.showConfirmDialog(this, formulario,
                original == null ? "Agregar al catálogo" : "Editar recurso o servicio",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (opcion != JOptionPane.OK_OPTION) return;
        if (nombre.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Escribe el nombre del recurso o servicio.");
            return;
        }
        try {
            BigDecimal valor = new BigDecimal(costo.getText().trim().replace(',', '.'));
            if (valor.signum() < 0) throw new NumberFormatException();
            Long unidades = capacidad.getText().trim().isEmpty()
                    ? null : Long.valueOf(capacidad.getText().trim());
            if (unidades != null && unidades < 0) throw new NumberFormatException();
            Servicio servicio = original == null ? new Servicio(0, nombre.getText().trim(), valor) : original;
            servicio.setNombre(nombre.getText().trim());
            servicio.setCostoUnitario(valor);
            servicio.setCantidadDisponible(unidades);
            catalogoEventoDAO.guardarServicio(servicio);
            cargarModulo("Servicios", modelo);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Revisa costo y disponibilidad. La disponibilidad debe ser "
                    + "un entero mayor o igual a cero; déjala vacía si aún no se conoce.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo guardar el recurso: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Long leerCapacidad(Object valor) {
        if (valor == null || "Sin informar".equalsIgnoreCase(String.valueOf(valor))) return null;
        if (valor instanceof Number) return ((Number) valor).longValue();
        try { return Long.valueOf(String.valueOf(valor)); }
        catch (NumberFormatException ex) { return null; }
    }

    private void eliminarServicioSeleccionado(JTable tabla, DefaultTableModel modelo) {
        int filaVista = tabla.getSelectedRow();
        if (filaVista < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un recurso del catálogo.");
            return;
        }
        int fila = tabla.convertRowIndexToModel(filaVista);
        int id = (Integer) modelo.getValueAt(fila, 0);
        String nombre = String.valueOf(modelo.getValueAt(fila, 1));
        int opcion = JOptionPane.showConfirmDialog(this,
                "¿Quitar '" + nombre + "' del catálogo? Si ya se usa en un paquete o evento, la base lo protegerá.",
                "Confirmar", JOptionPane.YES_NO_OPTION);
        if (opcion != JOptionPane.YES_OPTION) return;
        try {
            catalogoEventoDAO.eliminarServicio(id);
            cargarModulo("Servicios", modelo);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "No se puede quitar: el recurso ya está asociado a un paquete o evento.\n" + ex.getMessage(),
                    "Recurso en uso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void configurarTabla(JTable tabla) {
        PanelRolUI.estilizarTabla(tabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    private JButton crearBotonEstilizado(String texto, Color colorBase) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Verdana", Font.BOLD, 12));
        boton.setForeground(Color.WHITE);
        boton.setBackground(colorBase);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                if (colorBase == NARANJA) boton.setBackground(NARANJA_HOVER);
                else boton.setBackground(colorBase.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(colorBase);
            }
        });
        return boton;
    }

    private void cargarModulo(String nombre, DefaultTableModel modelo) {
        try {
            DatosTabla datos = consultaDAO.consultar(nombre);
            Object[][] matrizFilas = datos.getFilas().toArray(new Object[0][]);
            modelo.setDataVector(matrizFilas, datos.getColumnas());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo cargar " + nombre + ": " + ex.getMessage(),
                    "Error de consulta", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void cargarClientes() {
        try {
            modeloClientes.setRowCount(0);
            List<Cliente> clientes = clienteDAO.listarTodos();
            for (Cliente c : clientes) {
                modeloClientes.addRow(new Object[] {c.getIdCliente(), c.getNombre(), c.getApellido(),
                        c.getDniCuit(), c.getEmail(), c.getTelefono()});
            }
        } catch (SQLException ex) { mostrarError(ex); }
    }

    private void nuevoCliente() {
        Cliente cliente = pedirDatos(null);
        if (cliente == null) return;
        try {
            clienteDAO.insertar(cliente);
            cargarClientes();
            JOptionPane.showMessageDialog(this, "Cliente guardado correctamente.");
        } catch (SQLException ex) { mostrarError(ex); }
    }

    private void editarCliente() {
        Cliente seleccionado = clienteSeleccionado();
        if (seleccionado == null) return;
        Cliente cambios = pedirDatos(seleccionado);
        if (cambios == null) return;
        cambios.setIdCliente(seleccionado.getIdCliente());
        try {
            if (clienteDAO.actualizar(cambios)) {
                cargarClientes();
                JOptionPane.showMessageDialog(this, "Cliente actualizado correctamente.");
            }
        } catch (SQLException ex) { mostrarError(ex); }
    }

    private void eliminarCliente() {
        Cliente cliente = clienteSeleccionado();
        if (cliente == null) return;
        int confirmar = JOptionPane.showConfirmDialog(this,
                "Se eliminará a " + cliente.getNombre() + " " + cliente.getApellido() + ". ¿Deseas continuar?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (confirmar != JOptionPane.YES_OPTION) return;
        try {
            clienteDAO.eliminar(cliente.getIdCliente());
            cargarClientes();
            JOptionPane.showMessageDialog(this, "Cliente eliminado.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo eliminar. Es posible que el cliente ya tenga eventos asociados.\n"
                            + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Cliente clienteSeleccionado() {
        int fila = tablaClientes.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona primero un cliente de la tabla.");
            return null;
        }
        fila = tablaClientes.convertRowIndexToModel(fila);
        return new Cliente((Integer) modeloClientes.getValueAt(fila, 0),
                (String) modeloClientes.getValueAt(fila, 1), (String) modeloClientes.getValueAt(fila, 2),
                (String) modeloClientes.getValueAt(fila, 3), (String) modeloClientes.getValueAt(fila, 4),
                (String) modeloClientes.getValueAt(fila, 5));
    }

    private Cliente pedirDatos(Cliente actual) {
        JTextField nombre = new JTextField(actual == null ? "" : actual.getNombre());
        JTextField apellido = new JTextField(actual == null ? "" : actual.getApellido());
        JTextField dni = new JTextField(actual == null ? "" : actual.getDniCuit());
        JTextField email = new JTextField(actual == null ? "" : actual.getEmail());
        JTextField telefono = new JTextField(actual == null ? "" : actual.getTelefono());
        
        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 8));
        formulario.add(new JLabel("Nombre:")); formulario.add(nombre);
        formulario.add(new JLabel("Apellido:")); formulario.add(apellido);
        formulario.add(new JLabel("DNI/CUIT:")); formulario.add(dni);
        formulario.add(new JLabel("Email:")); formulario.add(email);
        formulario.add(new JLabel("Teléfono:")); formulario.add(telefono);
        
        int opcion = JOptionPane.showConfirmDialog(this, formulario,
                actual == null ? "Nuevo cliente" : "Editar cliente", JOptionPane.OK_CANCEL_OPTION);
        if (opcion != JOptionPane.OK_OPTION) return null;
        if (nombre.getText().trim().isEmpty() || apellido.getText().trim().isEmpty()
                || dni.getText().trim().isEmpty() || email.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nombre, apellido, DNI/CUIT y email son obligatorios.");
            return null;
        }
        return new Cliente(0, nombre.getText().trim(), apellido.getText().trim(),
                dni.getText().trim(), email.getText().trim(), telefono.getText().trim());
    }

    private void cerrarSesion() {
        int respuesta = JOptionPane.showConfirmDialog(this,
                "¿Deseas cerrar la sesión actual?", "Confirmar cierre de sesión",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (respuesta != JOptionPane.YES_OPTION) return;
        RegistroAccionesUI.establecerUsuario(null);
        dispose();
        new LoginFrame().setVisible(true);
    }

    private void mostrarError(SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error de base de datos: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}
